<?php
	include_once('connect.php');
	$queryString='
	CREATE TABLE Policy_Holders
	(
		
		Name varchar(10)
		Policy_ID int(20) PRIMARY KEY,
		Email varchar(30)
		Address varchar(30)
		Occupation varchar(50)
		Phone_Number int(20)
		ID_Number varchar(20)


	);
';

	if($Insurance_conn->query($queryString)){
		echo "Table created successfully";
	}
	else{
		echo "not created";
	}
		


?>