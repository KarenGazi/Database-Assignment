<?php

$Insurance_conn=new mysqli('localhost','Insurance_User','12345','Insurance_db');
  if($Insurance_conn->connect_errno){
	  
	  echo "Error".$Insurance_conn->connect_errno." has occured";
	  
  }else{
		
	  echo "successfully connected";
  }
	
?>

