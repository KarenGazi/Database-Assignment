
<?php
 include_once('connect.php');
		$Name =$_POST["username"];
		$Email=$_POST["email"];
		$Address=$_POST["Address"];
		$Occupation=$_POST["Occupation"];
		$Phone_Number=$_POST["Phone_Number"];
		$ID_Number=$_POST["ID_Number"];

echo " $Name, $Email, $Address, $Occupation, $Phone_Number, $ID_Number ";

	
		$query_string="
			 INSERT INTO Policy_Holders
			 Values ('$Name','$email')
   		";

  if($Insurance_conn->query($query_string)){

  		 echo "Data inserted successfully";

   }

$_SESSION['welcome'] = $karen;
 header("Location: logged_on.php")
	  ?>
	